# Ariadne (Resident IO Chatbot) — Phased Implementation Checklist

This checklist is written to match the project’s priorities:
1) rebuild the base site, 2) integrate Ariadne safely, 3) add internet lookup only if necessary.

---

## Phase 0 — Site seam (no AI yet) ✅ (do this during the rebuild)

**Goal:** make Ariadne “slot-in ready” without blocking launch.

- [ ] Add top-level nav item: **Ariadne**
- [ ] Create `/ariadne` route with:
  - what it is, what it isn’t
  - scope discipline statement (Master is authoritative; Ariadne is downstream)
  - “status” banner: Offline / Coming soon
- [ ] Add a **site-wide link to Archive** (Rev5-early snapshot)
- [ ] Add a “Corpus” data layer in repo (even if minimal):
  - `content/papers.json` with titles, slugs, pdf paths, categories
- [ ] Add lightweight UI component for citations (even before chatbot)

Deliverable: site launches with Ariadne page “disabled” but designed.

---

## Phase 1 — Ariadne v1 (corpus-grounded only, no web)

**Goal:** safe default behavior that never drifts.

Backend
- [ ] Choose model/provider integration strategy (API-based)
- [ ] Build retrieval over local corpus:
  - store PDFs/text chunks (pre-processed) in a vector store
  - ensure answers cite source passages
- [ ] Add strict system instructions:
  - “Answer only from corpus; if missing, say ‘not in corpus’.”
  - “No new ontology claims.”

Frontend
- [ ] Chat UI on `/ariadne`
- [ ] Always show citations / sources panel
- [ ] Provide “Mode” selector (see Phase 2, but default locked to Explain)

Safety
- [ ] Add jailbreak heuristics:
  - roleplay detection
  - “ignore previous instructions” detection
  - prompt injection patterns
- [ ] Add refusal templates:
  - short, polite, consistent
- [ ] Add rate limiting (IP-based at minimum)

Acceptance criteria
- [ ] Every answer includes at least one citation OR a clear “not in corpus.”
- [ ] Roleplay unrelated to philosophy triggers refusal.
- [ ] “Extend/revise IO” requests trigger refusal.

---

## Phase 2 — Adversarial modes (still no web)

**Goal:** make it genuinely useful for philosophical stress-testing while staying bounded.

- [ ] Add explicit modes:
  - Explain (default)
  - Adversarial critic (bounded)
  - Misreading detector
  - Scope lock
- [ ] Each mode has:
  - a narrow prompt template
  - strict output format
  - refusal conditions

Acceptance criteria
- [ ] Adversarial mode cannot introduce new claims; it only challenges interpretation and coherence *within* corpus.

---

## Phase 3 — Account system + moderation controls (if needed)

**Goal:** deter abuse, enable banning, reduce spam.

- [ ] Add auth (Clerk/Supabase auth/etc.)
- [ ] Gate `/ariadne` behind login (optional toggle)
- [ ] Tie usage to user ID
- [ ] Add abuse log:
  - user_id, timestamps, refusal triggers, rate events
  - minimize stored content (privacy)
- [ ] Add ban list / blocklist

Acceptance criteria
- [ ] You can disable a user’s access without redeploying.
- [ ] Rate limiting is per-user and per-IP.

---

## Phase 4 — Constrained internet lookup for Compare-to-X (optional)

**Goal:** allow “how does IO differ from X?” without external contamination.

- [ ] Add a *separate* “Lookup” step only invoked in Compare-to-X mode.
- [ ] Restrict domains or sources (high-quality reference sources only).
- [ ] Require a split output:
  - Section A: “External overview (summary)”
  - Section B: “IO comparison (corpus-grounded)”
- [ ] Never allow external sources to override corpus claims.
- [ ] Log lookups and show the user what was consulted.

Acceptance criteria
- [ ] If lookup fails, bot still answers from corpus with caveats.
- [ ] Bot never “updates” IO based on lookup.

---

## Phase 5 — Hardening & observability

- [ ] Add prompt-injection regression tests (a small local suite)
- [ ] Add “red team” prompt library (common jailbreak patterns)
- [ ] Add dashboard metrics:
  - refusal rate
  - top queries
  - citation coverage rate
- [ ] Add a “Report answer” button

---

## Minimal Deliverables Summary

- **Launch-ready site**: Phase 0
- **Useful Ariadne**: Phase 1 + Phase 2
- **Abuse-resistant**: Phase 3
- **Comparative capability**: Phase 4 (optional)

