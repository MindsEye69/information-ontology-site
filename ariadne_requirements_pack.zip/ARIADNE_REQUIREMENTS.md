# Ariadne (Resident IO Chatbot) — Requirements (Seed)

Source: **Resident IO Chatbot Idea.docx** (Jan 2026).  
Purpose: capture the *initial* product and safety requirements for the “resident GPT” concept, so implementation can proceed without re-litigating intent.

---

## 1. Goal

A resident chatbot (working name **Ariadne**) integrated into the Information Ontology website that can:

- answer public questions about Informational Ontology (IO),
- engage in philosophical dialogue / debate *within strict constraints*,
- reduce inbound email/support load by routing common questions to the interface.

---

## 2. Core concerns (non-negotiables)

### 2.1 Safety: prevent “off-script” behavior
- The chatbot must resist misuse and attempts to steer it away from IO content or project scope.
- The system should include explicit anti-jailbreak posture (see §5).

### 2.2 Scope discipline
- The chatbot must not “extend,” “revise,” or “repair” IO.
- When information is not in the corpus, it should say so and redirect appropriately.

---

## 3. Capabilities

### 3.1 Corpus-grounded Q&A (baseline)
- Primary behavior: answer from IO corpus materials.
- Prefer answers that cite/point to the relevant paper(s).

### 3.2 Philosophical dialogue / debate (bounded)
- The chatbot should be able to engage philosophically, but only using:
  - IO’s own vocabulary and commitments, and
  - approved “adversarial modes” (see §6).

### 3.3 Optional: limited internet lookup for comparisons
Motivation example:
- User asks: “How is this different from philosophy X?”
- The bot may need to look up “philosophy X” to provide comparison context.

Constraint:
- Internet lookup must be limited and sandboxed to avoid:
  - importing external claims as authority over IO,
  - contamination of IO’s canonical claims.

---

## 4. Access control & accountability (optional escalation)

### 4.1 Login requirement
- Consider requiring login to access Ariadne, to discourage abuse.
- Tie each conversation / usage to an account.

### 4.2 Moderation primitives
- Ability to ban accounts for repeated misuse.
- Basic logging sufficient for abuse handling (privacy-minimal).

---

## 5. Anti-jailbreak behavior (design requirement)

Observation:
- Many jailbreak attempts use roleplay prompts.

Desired behavior:
- Detect roleplay / instruction-manipulation patterns.
- Allow roleplay only if clearly relevant to philosophical inquiry and the IO corpus.
- Otherwise politely refuse.

---

## 6. “Adversarial interface” modes (recommended feature)

Ariadne should support explicit modes that help stress-test understanding without drifting:
- **Explain** (default): give grounded answers with citations.
- **Adversarial critic**: “what would a critic say?” (bounded to allowed critique patterns).
- **Misreading detector**: point out likely interpretive errors and correct them using corpus text.
- **Scope lock**: remind the user what is and isn’t permitted (no ontology revisions).
- **Compare-to-X**: (only if lookup enabled) separate “external overview” from “IO’s position”.

---

## 7. Tech assumptions (initial)

Known services:
- Vercel deployment
- GitHub repo
- Domene.no domain/DNS

Preferred stack notes:
- Site framework: **Next.js**
- Auth: prefer free option (e.g., Clerk if free/viable)
- Data/user system: **Supabase** likely optimal unless auth provider covers needs

---

## 8. Implementation posture

This feature is “extra functionality” beyond baseline site scope.
Recommended plan:
- Launch the new site first.
- Integrate Ariadne in phases (see implementation checklist file).

